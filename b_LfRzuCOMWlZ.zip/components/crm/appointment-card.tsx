'use client';

import { Appointment, Customer } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, User, Trash2 } from 'lucide-react';

interface AppointmentCardProps {
  appointment: Appointment;
  customer?: Customer;
  onEdit?: (appointment: Appointment) => void;
  onDelete?: (id: string) => void;
}

export function AppointmentCard({
  appointment,
  customer,
  onEdit,
  onDelete,
}: AppointmentCardProps) {
  const statusColor = {
    scheduled: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    canceled: 'bg-red-100 text-red-800',
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold">{appointment.title}</h3>
            {customer && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <User className="w-3 h-3" />
                {customer.name}
              </p>
            )}
          </div>
          <span
            className={`px-2 py-1 rounded text-xs font-medium whitespace-nowrap ml-2 ${
              statusColor[appointment.status]
            }`}
          >
            {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
          </span>
        </div>

        {appointment.description && (
          <p className="text-sm text-muted-foreground">{appointment.description}</p>
        )}

        <div className="space-y-2 text-sm border-t pt-2">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(appointment.startTime)}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>
              {formatTime(appointment.startTime)} - {formatTime(appointment.endTime)}
            </span>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          {onEdit && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onEdit(appointment)}
              className="flex-1"
            >
              Edit
            </Button>
          )}
          {onDelete && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(appointment.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
