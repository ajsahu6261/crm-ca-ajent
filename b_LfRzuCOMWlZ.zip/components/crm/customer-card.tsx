'use client';

import { Customer } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mail, Phone, Building2, Clock } from 'lucide-react';

interface CustomerCardProps {
  customer: Customer;
  onEdit?: (customer: Customer) => void;
  onDelete?: (id: string) => void;
}

export function CustomerCard({ customer, onEdit, onDelete }: CustomerCardProps) {
  const statusColor = {
    active: 'bg-green-100 text-green-800',
    prospect: 'bg-blue-100 text-blue-800',
    inactive: 'bg-gray-100 text-gray-800',
  };

  return (
    <Card className="p-4 hover:shadow-lg transition-shadow">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-base">{customer.name}</h3>
            <p className="text-xs text-muted-foreground">{customer.company}</p>
          </div>
          <span className={`px-2 py-1 rounded text-xs font-medium ${statusColor[customer.status]}`}>
            {customer.status.charAt(0).toUpperCase() + customer.status.slice(1)}
          </span>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Mail className="w-4 h-4" />
            <a href={`mailto:${customer.email}`} className="hover:text-primary">
              {customer.email}
            </a>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Phone className="w-4 h-4" />
            <a href={`tel:${customer.phone}`} className="hover:text-primary">
              {customer.phone}
            </a>
          </div>
          {customer.lastContactDate && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Last contact: {customer.lastContactDate.toLocaleDateString()}</span>
            </div>
          )}
        </div>

        {customer.notes && (
          <p className="text-xs text-muted-foreground border-t pt-2">
            {customer.notes}
          </p>
        )}

        <div className="flex gap-2 pt-2">
          {onEdit && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onEdit(customer)}
              className="flex-1"
            >
              Edit
            </Button>
          )}
          {onDelete && (
            <Button
              size="sm"
              variant="ghost"
              className="text-red-600 hover:bg-red-50"
              onClick={() => onDelete(customer.id)}
            >
              Delete
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
