'use client';

import { Appointment, Customer } from '@/lib/types';
import { AppointmentCard } from './appointment-card';

interface AppointmentListProps {
  appointments: Appointment[];
  customers: Customer[];
  title?: string;
  onEdit?: (appointment: Appointment) => void;
  onDelete?: (id: string) => void;
}

export function AppointmentList({
  appointments,
  customers,
  title = 'Appointments',
  onEdit,
  onDelete,
}: AppointmentListProps) {
  const getCustomer = (customerId: string) => {
    return customers.find((c) => c.id === customerId);
  };

  return (
    <div className="space-y-4">
      {title && <h2 className="text-lg font-semibold">{title}</h2>}

      {appointments.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <p>No appointments found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {appointments.map((appointment) => (
            <AppointmentCard
              key={appointment.id}
              appointment={appointment}
              customer={getCustomer(appointment.customerId)}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}
