'use client';

import { Customer } from '@/lib/types';
import { CustomerCard } from './customer-card';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

interface CustomerListProps {
  customers: Customer[];
  onEdit?: (customer: Customer) => void;
  onDelete?: (id: string) => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
}

export function CustomerList({
  customers,
  onEdit,
  onDelete,
  searchQuery = '',
  onSearchChange,
}: CustomerListProps) {
  return (
    <div className="space-y-4">
      {onSearchChange && (
        <div className="relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search customers by name, email, or company..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>
      )}

      {customers.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No customers found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {customers.map((customer) => (
            <CustomerCard
              key={customer.id}
              customer={customer}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}
