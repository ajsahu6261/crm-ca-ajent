'use client';

import { MessageList } from './message-list';
import { MessageInput } from './message-input';
import { useChat } from '@/hooks/useChat';
import { useCRM } from '@/hooks/useCRM';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function ChatInterface() {
  const { messages, isLoading, sendMessage, selectedCustomerId, setCustomerContext } = useChat();
  const { customers } = useCRM();

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-border bg-gradient-to-r from-background to-background/80">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">AI Chat Assistant</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Chat with your AI CRM assistant for smart customer management
            </p>
          </div>
          <div className="w-full sm:w-72">
            <Select
              value={selectedCustomerId || 'none'}
              onValueChange={(value) =>
                setCustomerContext(value === 'none' ? undefined : value)
              }
            >
              <SelectTrigger className="bg-muted">
                <SelectValue placeholder="Select a customer..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No customer selected</SelectItem>
                {customers.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Messages */}
      <MessageList messages={messages} isLoading={isLoading} />

      {/* Input */}
      <MessageInput onSend={sendMessage} isLoading={isLoading} />
    </div>
  );
}
