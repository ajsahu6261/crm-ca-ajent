// Customer type definition
export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  notes: string;
  createdAt: Date;
  lastContactDate?: Date;
  status: 'active' | 'inactive' | 'prospect';
}

// Appointment type definition
export interface Appointment {
  id: string;
  customerId: string;
  title: string;
  description: string;
  startTime: Date;
  endTime: Date;
  status: 'scheduled' | 'completed' | 'canceled';
  createdAt: Date;
}

// Chat message type definition
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  customerId?: string;
}

// Chat session type definition
export interface ChatSession {
  id: string;
  customerId?: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}
