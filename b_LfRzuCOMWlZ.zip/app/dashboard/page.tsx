'use client';

import { useCRM } from '@/hooks/useCRM';
import { CustomerList } from '@/components/crm/customer-list';
import { AppointmentList } from '@/components/crm/appointment-list';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Users, Calendar } from 'lucide-react';
import { useState } from 'react';

export default function DashboardPage() {
  const { customers, appointments, getUpcomingAppointments, searchQuery, setSearchQuery } = useCRM();
  const upcomingAppointments = getUpcomingAppointments();

  const [view, setView] = useState<'overview' | 'customers' | 'appointments'>('overview');

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 animate-in fade-in duration-500">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your customers and appointments efficiently
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 animate-in fade-in duration-500 delay-200">
          <Card className="p-6 card-hover">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Customers</p>
                <p className="text-3xl font-bold">{customers.length}</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Upcoming</p>
                <p className="text-3xl font-bold">{upcomingAppointments.length}</p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <Calendar className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Active</p>
                <p className="text-3xl font-bold">
                  {customers.filter((c) => c.status === 'active').length}
                </p>
              </div>
              <div className="p-3 bg-purple-100 rounded-lg">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </Card>
        </div>

        {/* View Selector */}
        <div className="flex gap-2 mb-6 animate-in fade-in duration-500 delay-300">
          <Button
            variant={view === 'overview' ? 'default' : 'outline'}
            onClick={() => setView('overview')}
          >
            Overview
          </Button>
          <Button
            variant={view === 'customers' ? 'default' : 'outline'}
            onClick={() => setView('customers')}
          >
            All Customers
          </Button>
          <Button
            variant={view === 'appointments' ? 'default' : 'outline'}
            onClick={() => setView('appointments')}
          >
            All Appointments
          </Button>
        </div>

        {/* Content */}
        {view === 'overview' && (
          <div className="space-y-8">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Upcoming Appointments</h2>
              </div>
              <AppointmentList
                appointments={upcomingAppointments.slice(0, 3)}
                customers={customers}
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Recent Customers</h2>
              </div>
              <CustomerList customers={customers.slice(0, 6)} />
            </div>
          </div>
        )}

        {view === 'customers' && (
          <CustomerList
            customers={customers}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        )}

        {view === 'appointments' && (
          <AppointmentList
            title="All Appointments"
            appointments={appointments}
            customers={customers}
          />
        )}
      </div>
    </div>
  );
}
