'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MessageSquare, LayoutDashboard, Zap, Users, BarChart3 } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/50">
      {/* Navigation */}
      <div className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-xl">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground">
              AI
            </div>
            <span>CRM AI Agent</span>
          </div>
          <div className="flex gap-3">
            <Link href="/chat">
              <Button variant="outline">Chat</Button>
            </Link>
            <Link href="/dashboard">
              <Button>Dashboard</Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center space-y-6 mb-12 animate-in fade-in duration-700">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
            Your AI-Powered{' '}
            <span className="gradient-text">
              CRM Assistant
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Manage customers, schedule appointments, and automate your workflow with
            intelligent AI assistance.
          </p>
          <div className="flex gap-4 justify-center pt-4">
            <Link href="/chat">
              <Button size="lg">
                <MessageSquare className="w-5 h-5 mr-2" />
                Start Chatting
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="lg" variant="outline">
                <LayoutDashboard className="w-5 h-5 mr-2" />
                Go to Dashboard
              </Button>
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12 animate-in fade-in duration-700 delay-200">
          <Card className="p-6 border border-border card-hover">
            <div className="p-3 w-12 h-12 bg-blue-100 rounded-lg mb-4">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">AI Chat Assistant</h3>
            <p className="text-muted-foreground">
              Chat with your intelligent assistant to manage customers and get instant
              recommendations.
            </p>
          </Card>

          <Card className="p-6 border border-border hover:border-primary/50 hover:shadow-lg transition-all">
            <div className="p-3 w-12 h-12 bg-green-100 rounded-lg mb-4">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Customer Management</h3>
            <p className="text-muted-foreground">
              Centralize customer data, track interactions, and maintain detailed contact
              information.
            </p>
          </Card>

          <Card className="p-6 border border-border hover:border-primary/50 hover:shadow-lg transition-all">
            <div className="p-3 w-12 h-12 bg-purple-100 rounded-lg mb-4">
              <Zap className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Appointment Scheduling</h3>
            <p className="text-muted-foreground">
              Schedule and manage appointments with customers, receive reminders and
              follow-ups.
            </p>
          </Card>
        </div>

        {/* Secondary Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-8 animate-in fade-in duration-700 delay-300">
          <Card className="p-6 card-hover">
            <div className="flex items-start gap-4">
              <div className="p-3 w-12 h-12 bg-blue-100 rounded-lg flex-shrink-0">
                <BarChart3 className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Analytics Dashboard</h4>
                <p className="text-sm text-muted-foreground">
                  Track customer metrics, appointment history, and activity trends at a
                  glance.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 w-12 h-12 bg-red-100 rounded-lg flex-shrink-0">
                <Zap className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Smart Automation</h4>
                <p className="text-sm text-muted-foreground">
                  Automate routine tasks and get AI-powered insights for better decision
                  making.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="border-t border-border bg-muted/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Start managing your customers more efficiently with AI-powered assistance.
          </p>
          <Link href="/chat">
            <Button size="lg">
              Open Chat Assistant
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
