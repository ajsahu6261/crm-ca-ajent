'use client';

import { useState, useCallback } from 'react';
import { Message, ChatSession } from '@/lib/types';
import { mockInitialMessages } from '@/lib/mock-data';

const CHAT_STORAGE_KEY = 'crm_chat_session';

export function useChat() {
  const [messages, setMessages] = useState<Message[]>(mockInitialMessages);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | undefined>();

  // Mock AI response generator
  const generateAIResponse = (userMessage: string, customerId?: string): string => {
    const responses = [
      'I understand. Let me help you with that.',
      'That\'s a great question. Based on the customer data, I can help you with that.',
      'I\'ve noted that. Would you like me to schedule an appointment or send a follow-up email?',
      'I can see this is important. Let me provide some insights on this.',
      'Based on the customer\'s history, I recommend the following action steps.',
      'I\'ll help you manage this. Would you like me to create a task or send a reminder?',
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  };

  const sendMessage = useCallback(
    async (content: string) => {
      if (!content.trim()) return;

      const userMessage: Message = {
        id: `msg-${Date.now()}`,
        role: 'user',
        content,
        timestamp: new Date(),
        customerId: selectedCustomerId,
      };

      setMessages((prev) => [...prev, userMessage]);
      setIsLoading(true);

      // Simulate AI response delay
      setTimeout(() => {
        const aiResponse: Message = {
          id: `msg-${Date.now()}-ai`,
          role: 'assistant',
          content: generateAIResponse(content, selectedCustomerId),
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, aiResponse]);
        setIsLoading(false);
      }, 800);
    },
    [selectedCustomerId]
  );

  const clearMessages = useCallback(() => {
    setMessages(mockInitialMessages);
  }, []);

  const setCustomerContext = useCallback((customerId: string | undefined) => {
    setSelectedCustomerId(customerId);
  }, []);

  return {
    messages,
    isLoading,
    selectedCustomerId,
    sendMessage,
    clearMessages,
    setCustomerContext,
  };
}
