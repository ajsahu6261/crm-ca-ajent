'use client';

import { useState, useCallback, useMemo } from 'react';
import { Customer, Appointment } from '@/lib/types';
import { mockCustomers, mockAppointments } from '@/lib/mock-data';

export function useCRM() {
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter customers based on search query
  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) {
      return customers;
    }
    const query = searchQuery.toLowerCase();
    return customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(query) ||
        customer.email.toLowerCase().includes(query) ||
        customer.company.toLowerCase().includes(query)
    );
  }, [customers, searchQuery]);

  // Get customer by ID
  const getCustomer = useCallback(
    (id: string) => {
      return customers.find((c) => c.id === id);
    },
    [customers]
  );

  // Get appointments for a customer
  const getCustomerAppointments = useCallback(
    (customerId: string) => {
      return appointments.filter((apt) => apt.customerId === customerId);
    },
    [appointments]
  );

  // Get upcoming appointments
  const getUpcomingAppointments = useCallback(() => {
    const now = new Date();
    return appointments
      .filter((apt) => apt.startTime > now && apt.status === 'scheduled')
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
      .slice(0, 5);
  }, [appointments]);

  // Add customer
  const addCustomer = useCallback((customer: Omit<Customer, 'id' | 'createdAt'>) => {
    const newCustomer: Customer = {
      ...customer,
      id: `cust-${Date.now()}`,
      createdAt: new Date(),
    };
    setCustomers((prev) => [...prev, newCustomer]);
    return newCustomer;
  }, []);

  // Update customer
  const updateCustomer = useCallback((id: string, updates: Partial<Customer>) => {
    setCustomers((prev) =>
      prev.map((customer) => (customer.id === id ? { ...customer, ...updates } : customer))
    );
  }, []);

  // Delete customer
  const deleteCustomer = useCallback((id: string) => {
    setCustomers((prev) => prev.filter((customer) => customer.id !== id));
  }, []);

  // Add appointment
  const addAppointment = useCallback((appointment: Omit<Appointment, 'id' | 'createdAt'>) => {
    const newAppointment: Appointment = {
      ...appointment,
      id: `apt-${Date.now()}`,
      createdAt: new Date(),
    };
    setAppointments((prev) => [...prev, newAppointment]);
    return newAppointment;
  }, []);

  // Update appointment
  const updateAppointment = useCallback((id: string, updates: Partial<Appointment>) => {
    setAppointments((prev) =>
      prev.map((appointment) => (appointment.id === id ? { ...appointment, ...updates } : appointment))
    );
  }, []);

  // Delete appointment
  const deleteAppointment = useCallback((id: string) => {
    setAppointments((prev) => prev.filter((appointment) => appointment.id !== id));
  }, []);

  return {
    customers,
    filteredCustomers,
    appointments,
    searchQuery,
    setSearchQuery,
    getCustomer,
    getCustomerAppointments,
    getUpcomingAppointments,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addAppointment,
    updateAppointment,
    deleteAppointment,
  };
}
